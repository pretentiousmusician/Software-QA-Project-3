import pexpect
from pexpect import *
import thread
import time

p_one_place = ['a:1', 'a:5', 'b:1', 'b:4', 'c:1', 'c:3',
'd:1', 'd:3','e:1', 'e:2']

p_two_place = ['j:10', 'j:6', 'i:10', 'i:7', 'h:10', 'h:8',
'g:10', 'g:8', 'f:10', 'f:9']

p_one_attack = [('a', 1), ('b', 1), ('c', 1), ('d', 1), ('e', 1)]
p_two_attack = [('j', 6), ('i', 7), ('h', 8), ('g', 8), ('f', 9)]

ship_lengths = [5, 4, 3, 3, 2]

ship_names = ['Carrier', 'Battleship', 'Cruiser', 'Submarine', 'Destroyer']



def play():
    thread.start_new_thread(spawn, ('java -jar BattleshipServer.jar', ))
    print("Spawned Server")
    time.sleep(3)

    thread.start_new_thread(play_client, (p_one_place, p_one_attack, 1,))
    print("Started thread for Player 1")
    time.sleep(0.1)
    thread.start_new_thread(play_client, (p_two_place, p_two_attack, 2,))
    print("Started thread for Player 2")
    time.sleep(5)

def play_client(place, attack, pnum):
    player = spawn('java -jar BattleshipClient.jar')
    print("Placing ships for player " + str(pnum))
    for i in range(10, 2):
        player.expect("Please enter a.* coordinate to place your "+str(ship_names[i/2]))

        #player.expect(pexpect.EOF, timeout=None)
        player.sendline(place[i])
        player.expect(".*"+ str(ship_names[i/2]))

        #player.expect(pexpect.EOF, timeout=None)
        player.sendline(place[i+1])
        #Might have a problem w/ concatenation here...
    #print("Ships are set for " + str(pnum))
    #time.sleep(1)
    #player.expect("(The game is starting!)")
    #time.sleep(2)
    print("Player " + str(pnum) + " is ready to attack")

    player.expect('(The game is starting!)*')

    for j in range(len(ship_lengths)):
        #for each ship
        for k in range(ship_lengths[j]):
            #for each space the ship takes up
            while True:
                try:
                    player.expect('Where would you like to place you move?\n')

                    player.expect("Used coordinates are [.*]")

                    player.expect("Hit coordinates are [.*]")

                    break
                except EOF:
                    break
            #player.expect(EOF)
            #print(player.before)
            #player.expect(pexpect.EOF, timeout=None)
            player.sendline(str(attack[j][0]) + (':' + str(attack[j][1]+k)))
    if pnum == 1:
        #player.expect("You won!\r\nThe Game is Over!")
        while True:
            try:
                player.expect("You won!")

                player.expect("The Game is Over!")

                print("Player 1 won as expected")
                break
            except EOF:
                print("Reached EOF")
                break
    elif pnum == 2:
        while True:
            try:
                player.expect("You lost...")

                player.expect("The Game is Over!")

                print("Player 2 lost as expected!")
                break
            except EOF:
                print("Reached EOF")
                break
    print("The game is over! Player 1 won")

play()
